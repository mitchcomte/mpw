# My Portland Wedding — Production App

A multi-market-ready wedding vendor directory built with Next.js, Supabase/Postgres, and Stripe.

## Included
- Public wedding vendor directory
- 22 vendor industries
- Market-aware architecture for future city sites
- Basic / Professional / Premium subscriptions
- Vendor signup/login
- Vendor dashboard
- Admin dashboard
- Leads and inquiry tracking
- Favorites-ready data model
- Reviews-ready data model
- Featured rotation logic
- Stripe checkout + webhook routes
- Supabase schema and row-level-security starter policies
- SEO metadata + JSON-LD helpers
- Domain/deployment checklist

## Local setup
1. `npm install`
2. Copy `.env.example` to `.env.local`
3. Create Supabase project and run `supabase/schema.sql`
4. Create Stripe products/prices and paste IDs into `.env.local`
5. Run `npm run dev`

## Domain
After purchasing `myportlandwedding.com`, connect it to the chosen hosting provider (recommended: Vercel) and add the DNS records provided by that host.
